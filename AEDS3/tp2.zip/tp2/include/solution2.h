#ifndef SOLUTION2_H
#define SOLUTION2_H
#include <stdio.h>
#include "graph.h"

int solution2(Graph graph, int nrows, int ncols);
int lowestEnergy(Graph graph, int *pred, int nrows, int ncols);

#endif