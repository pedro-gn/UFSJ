#include "guloso.h"

// Calcula a energia minima para ir do vertice 0 ao vertice final
int energia_harry (int* caminho, int indice_caminho) {

    int energia_inicial = 1;    //Energia minima inicial
    int energia = 1;

    //Encontra a energia minima inicial
    for (int i = 0; i < indice_caminho; i++) {
        energia = energia + caminho[i];
        while(energia < 1) {
            energia++;
            energia_inicial++;
        }
    }

    return energia_inicial;
}

//Encontra o caminho a ser percorrido
int guloso (Graph *graph, int nrows, int ncols) {

    int* caminho = (int*)malloc(graph->nvertices * sizeof(int)); //Aloca NxM espaço para o caminho
    int indice_caminho = 0; 
    int indice_vertices = 0; 
    int melhor_vertice = 0;

    caminho[indice_caminho] = graph->vertices[0].value; //Atribui o vertice 0 na primeira posição do caminho
    indice_caminho++;

    //Encontra o melhor vertice para percorrer
    while (indice_vertices+1 < graph->nvertices) {

        int maior_aresta = INT_MIN, nova_aresta = INT_MIN;

        for(int i = 0; i < graph->nvertices; i++) {
            nova_aresta = graph->adjMatrix[indice_vertices][i];  
            if (nova_aresta > maior_aresta) {
                maior_aresta = nova_aresta;
                melhor_vertice = i;
            }
        }

        caminho[indice_caminho] = graph->vertices[melhor_vertice].value;
        indice_caminho++;
        indice_vertices = melhor_vertice;
    }

    //Chama a função energia_harry() para retornar a energia minima inicial que Harry deve ter para percorrer o caminho
    int energia = energia_harry(caminho, indice_caminho);
    free(caminho);
    
    return energia;
}